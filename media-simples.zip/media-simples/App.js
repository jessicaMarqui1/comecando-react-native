import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';

export default function App() {
  const [nota1, setNota1] = useState('');
  const [nota2, setNota2] = useState('');
  const [nota3, setNota3] = useState('');
  const [mensagem, setMensagem] = useState('');

  const calcularMedia = () => {
    const media = (parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3)) / 3;
    if (media < 6) {
      setMensagem('Reprovado');
    } else {
      setMensagem('Aprovado');
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        placeholder="Nota 1"
        onChangeText={text => setNota1(text)}
        value={nota1}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Nota 2"
        onChangeText={text => setNota2(text)}
        value={nota2}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Nota 3"
        onChangeText={text => setNota3(text)}
        value={nota3}
        keyboardType="numeric"
      />
      <Button title="Calcular Média" onPress={calcularMedia} />
      {mensagem !== '' && <Text style={{ marginTop: 20 }}>Situação: {mensagem}</Text>}
    </View>
  );
}
