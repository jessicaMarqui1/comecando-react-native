import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [nota1, setNota1] = useState('');
  const [nota2, setNota2] = useState('');
  const [nota3, setNota3] = useState('');
  const [mensagem, setMensagem] = useState('');

  const calcularMedia = () => {
    const media = (parseFloat(nota1) + parseFloat(nota2) + parseFloat(nota3)) / 3;
    if (media < 6) {
      setMensagem('Reprovado');
    } else {
      setMensagem('Aprovado');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora de Média</Text>
      <TextInput
        style={styles.input}
        placeholder="Nota 1"
        onChangeText={text => setNota1(text)}
        value={nota1}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Nota 2"
        onChangeText={text => setNota2(text)}
        value={nota2}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Nota 3"
        onChangeText={text => setNota3(text)}
        value={nota3}
        keyboardType="numeric"
      />
      <TouchableOpacity style={styles.button} onPress={calcularMedia}>
        <Text style={styles.buttonText}>Calcular Média</Text>
      </TouchableOpacity>
      {mensagem !== '' && <Text style={styles.result}>Situação: {mensagem}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f0f0f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    marginBottom: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  result: {
    fontSize: 20,
    fontWeight: 'bold',
  },
});
