import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

export default function Exercicio3() {
  const [valor1, setValor1] = useState('');
  const [valor2, setValor2] = useState('');
  const [valor3, setValor3] = useState('');
  const [resultado, setResultado] = useState('');

  const calcularRegraDeTres = () => {
    const res = (parseFloat(valor2) * parseFloat(valor3)) / parseFloat(valor1);
    setResultado(res.toString());
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Exercício 3: Calculadora de Regra de 3</Text>
      <TextInput
        style={styles.input}
        placeholder="Valor 1"
        onChangeText={text => setValor1(text)}
        value={valor1}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Valor 2"
        onChangeText={text => setValor2(text)}
        value={valor2}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Valor 3"
        onChangeText={text => setValor3(text)}
        value={valor3}
        keyboardType="numeric"
      />
      <TouchableOpacity style={styles.button} onPress={calcularRegraDeTres}>
        <Text style={styles.buttonText}>Calcular Regra de 3</Text>
      </TouchableOpacity>
      {resultado !== '' && <Text style={styles.result}>Resultado: {resultado}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f0f0f0',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    width: '90%',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#007bff',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  result: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: 'bold',
  },
});
